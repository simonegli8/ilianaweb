* PHP JPEG ICC profile manipulator 0.2 *
by Richard Toth aka risko (risko@risko.org)

https://sourceforge.net/projects/jpeg-icc
https://svn.code.sf.net/p/jpeg-icc/code/

https://github.com/slavicv/jpeg-icc

BSD license according to sourceforge.