!function(c) {
  c(function() {
    var e = c.support, a;
    a: {
      a = document.createElement("bootstrap");
      var d = {WebkitTransition:"webkitTransitionEnd", MozTransition:"transitionend", OTransition:"oTransitionEnd otransitionend", transition:"transitionend"}, b;
      for (b in d) {
        if (void 0 !== a.style[b]) {
          a = d[b];
          break a;
        }
      }
      a = void 0;
    }
    e.transition = a && {end:a};
  });
}(window.jQuery);
